class Player:
    def __init__(self,name):
        self.name = name
        self.hand = []


    def draw_cards(self,deck,num=1):
        for c in range(num):
            card = deck.draw_card()
            if card:
                self.hand.append(card)

    def play_card(self, index):
        return self.hand.pop(index)


    def has_won(self):
        return len(self.hand)== 0
    

    def show_hand(self):
        
        return " | ".join(f"{i}: {card}" for i, card in enumerate(self.hand))  
        

