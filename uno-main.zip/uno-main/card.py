from colorama import Fore, Back, Style

class Card:
    def __init__(self, color, number):
        self.color = color
        self.number = number

    def matches(self, other_card):
        return self.color == other_card.color or self.number == other_card.number

    def __str__(self):
        
        color_map = {
            "Red": Back.RED,
            "Green": Back.GREEN,
            "Blue": Back.BLUE,
            "Yellow": Back.YELLOW
        }

        bg = color_map.get(self.color, Back.WHITE) 
        return f"{bg}{Fore.BLACK} {self.number} {Style.RESET_ALL}"