from deck import Deck
from player import Player
from card import Card



from colorama import Fore, Back, Style


class Uno:
    def __init__(self, deck, players):
        
        self.deck = deck
        self.players = players
        self.discard_pile = [self.deck.draw_card()]  
        self.current_player_index = 0

        
        for p in self.players:
            p.draw_cards(self.deck, 7)

    def can_play(self, card, top_card):
        
        return card.matches(top_card)

    def switch_turn(self):
        
        self.current_player_index = (self.current_player_index + 1) % len(self.players)

    def human_turn(self, player, top_card):
        
        print("Your Hand:", player.show_hand())
        choice = input("Choose a card index to play or 'd' to draw: ")

        if choice.lower() == "d":
            player.draw_cards(self.deck, 1)
            print("You drew a card.")
            return False  

        try:
            choice = int(choice)
            chosen_card = player.hand[choice]

            if self.can_play(chosen_card, top_card):
                played_card = player.play_card(choice)
                self.discard_pile.append(played_card)
                print("You played:", played_card)
            else:
                print("That card cannot be played. Drawing instead.")
                player.draw_cards(self.deck, 1)
        except (ValueError, IndexError):
            print("Invalid choice. Drawing instead.")
            player.draw_cards(self.deck, 1)

        return player.has_won()

    def computer_turn(self, player, top_card):
        
        print("Computer's turn...")
        for i, card in enumerate(player.hand):
            if self.can_play(card, top_card):
                played_card = player.play_card(i)
                self.discard_pile.append(played_card)
                print("Computer played:", played_card)
                return player.has_won()

        
        player.draw_cards(self.deck, 1)
        print("Computer drew a card.")
        return player.has_won()

    def play(self):
        
        print(Back.CYAN + Fore.BLACK + "WELCOME TO UNO GAME" + Style.RESET_ALL)

        while True:
            player = self.players[self.current_player_index]
            top_card = self.discard_pile[-1]
            print("\nTop Card:", top_card)

            if player.name == "You":
                has_won = self.human_turn(player, top_card)
                if has_won:
                    print("\n You Win! ")
                    break
            else:
                has_won = self.computer_turn(player, top_card)
                if has_won:
                    print("\n Computer Wins!")
                    break

            
            self.switch_turn()