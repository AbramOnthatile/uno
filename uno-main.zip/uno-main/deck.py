import random
from card import Card

class Deck:
    def __init__(self):
        self.cards = []
         
         
        colors = ["Red","Yellow","Green","blue"]

        numbers = list(range(10))

        for color in colors:
            for number in numbers:
                self.cards.append(Card(color,number))
                self.cards.append(Card(color,number))


        random.shuffle(self.cards)


    def draw_card(self):
        if self.cards:
            return self.cards.pop()
        return None