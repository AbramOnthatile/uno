from deck import Deck
from player import Player
from uno import Uno

# create deck
deck = Deck()

# create players
player1 = Player("You")
player2 = Player("Computer")

# start game
game = Uno(deck, [player1, player2])
game.play()